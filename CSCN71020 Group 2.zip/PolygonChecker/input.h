#pragma once
//Maksymp-input for rectangle-interface
int** createCoordinateArray(int** CoordinateArray);//This function collects and checks user input and creates a pointer to the two-demensional array[4][2] with 4 coordinates of vertices of an assumed rectangle