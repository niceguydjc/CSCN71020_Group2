#pragma once
void calculateTriangleAngles(double side_1, double side_2, double side_3);